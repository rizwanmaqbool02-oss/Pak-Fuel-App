const CACHE='pk-fuel-v3';
const ASSETS=['/','/index.html','/manifest.json'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)));self.skipWaiting();});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));self.clients.claim();});
self.addEventListener('fetch',e=>{if(e.request.url.includes('api.anthropic')||e.request.url.includes('googleapis')||e.request.url.includes('jsdelivr'))return;e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request)));});
